
function [bw, residentialregionsize] = residentialregionsize(im1)

level = graythresh(im1);
bw = im2bw(im1,level); 
b = 1-bw;
bw = imfill(b,'holes');
figure, imshow(b,[]);

[k,l] = find(bw==1);

disp('size of residential region:');
residentialregionsize = size(k,1)
disp('pixels');