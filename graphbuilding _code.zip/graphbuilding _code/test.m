

clear all
close all
clc
warning off;
iptsetpref('ImshowBorder','tight');
 
im=['IMAGES:  adana1 - adana19  ';
     '                           '];    
 
disp(im)
 
 imname = input('enter choice:  ');
img =imread(['images\' imname '.tif']);

% tsta=cputime;

%% preprocess:
im1 = imresize(double(img),6,'bilinear');
% time0=cputime-tsta;

% tsta=cputime;
%bilateral:
w     = 5;       % bilateral filter half-width
sigma = [3 0.1]; % bilateral filter standard deviations
imm1 = im1/max(im1(:));
bflt_im1 = bfilter2(imm1,w,sigma);
im1 = 255*bflt_im1;

% time1=cputime-tsta;

load temp1;
load temp2;

% figure, imshow(im1, []);
% figure, imshow(temp1, []);
% figure, imshow(temp2, []);
clear bflt_im1 w sigma imm1;
%%  sift:

% tsta=cputime;
[des1, loc1] = sift(im1);
[dest1, loct1] = sift(temp1);
[dest2, loct2] = sift(temp2);

% time2=cputime-tsta;
%% multiple matching:

% tsta=cputime;

% match with 1st model image:
%[locst1, locs1, match1, num1] = matchspecial(dest1, des1, loct1, loc1, 60);
% [locst1, locs1, match1, num1] = matchspecial2(dest1, des1, loct1, loc1, 60);
[locst1, locs1, match1, N1] = matchspecial3(dest1, des1, loct1, loc1);
% showscenekeys(im1, locs1);

% match with 2nd model image:
% [locst2, locs2, match2, num2] = matchspecial(dest2, des1, loct2, loc1, 60);
[locst2, locs2, match2, N2] = matchspecial3(dest2, des1, loct2, loc1);
% showscenekeys(im1, locs2);

% shift keys towards the buildings:
lc1 = shiftkeys(im1, locs1);
lc2 = shiftkeys(im1, locs2);
% time3=cputime-tsta;
% tsta=cputime;
clear des1 dest1 dest2 N1 N2;
%% construct graph:

[dis1] = distance2(loc1', loc1');
[distt1] = distance2(loct1', loct1');
[distt2] = distance2(loct2', loct2');

%% find residential regions:

err = 4;
% find sub-graphs
g1 = makesub2(im1, distt1, dis1, loct1, loc1, match1, err);
region_mask1 = findregionmask3(im1, g1, loc1);

g2 = makesub2(im1, distt2, dis1, loct2, loc1, match2, err);
region_mask2 = findregionmask3(im1, g2, loc1);

[sx sy]=size(img);

mask = region_mask1 | region_mask2;

% time4=cputime-tsta;
drawregions2(img, imresize(mask,[sx sy],'nearest'));


