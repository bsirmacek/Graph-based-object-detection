

function gnew = makenewgraph(im1,g,loc1,match1)


for(i = 1:size(g,1))
    newloc(i,1) = round(((loc1((g(i,3)),1)+loc1((g(i,4)),1)))/2); 
    newloc(i,2) = round(((loc1((g(i,3)),2)+loc1((g(i,4)),2)))/2);
end

[diss] = distance2(newloc', newloc');

k = 1;
for(i = 1:size(diss,1)-1)
    for(j = i+1:size(diss,1))
        if(i ~= j)
            if(diss(i,j)<15)
                gnew(k,:) = [i,j];
                k=k+1;
            end
        end
    end
end


figure, imshow(im1, []); hold on;

for(i = 1:size(gnew,1))
    line([newloc(gnew(i,1),2) newloc(gnew(i,2),2)], ...
         [newloc(gnew(i,1),1) newloc(gnew(i,2),1)], 'Color', 'r', 'LineWidth', 2.5);
         hold on;
    plot(newloc(i,2), newloc(i,1), '.b'); hold on;
end

hold off;