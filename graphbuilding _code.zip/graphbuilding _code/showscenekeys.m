function showscenekeys(im, loc)

figure, imshow(im,[]);
hold on;

f = size(loc(:,1));

for(i = 1:f)
%    plot(loc(i,2),loc(i,1),'.b', 'Markersize', 10);%adana 8 demo icin
    plot(loc(i,2),loc(i,1),'.b', 'Markersize', 5);
end

hold off;