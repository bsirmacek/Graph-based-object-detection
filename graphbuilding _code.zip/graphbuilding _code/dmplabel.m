function [labmax,labpc]=dmplabel(img)
 
t=3:3:24;

dummyold=img;

lt=length(t);

dmp=[];

for a=1:lt
se=strel('disk',t(a),0);
dummy=imdilate(imerode(img,se),se);
dif=abs(dummyold-dummy);
dmp(a,:,:)=dif;
dummyold=dummy;
end;

dummyold=img;

for a=lt+1:2*lt
se=strel('disk',t(a-lt),0);
dummy=imerode(imdilate(img,se),se);
dif=abs(dummy-dummyold);
dmp(a,:,:)=dif;
dummyold=dummy;
end;


[sx,sy]=size(img);


labmax=zeros(sx,sy);

for a=1:sx
    for b=1:sy
    pl=find(dmp(:,a,b)==max(dmp(:,a,b)));
    labmax(a,b)=pl(1);
    end;
end;

X=[];

for a=1:size(dmp,1)
    dummy=reshape(dmp(a,:,:),sx,sy);
    X(a,:)=reshape(dummy,1,sx*sy);
end;

    
[pc, Xn]=princomp(X');

Xn=Xn';

labpc=reshape(Xn(1,:,:),sx,sy);



