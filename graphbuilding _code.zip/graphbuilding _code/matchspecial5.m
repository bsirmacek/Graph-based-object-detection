

function [locs1, locs2, matchs, N] = matchspecial5(des1, des2, loc1, loc2)

N=0;
% For each descriptor in the first image, select its match to second image.
des2t = des2';      % Precompute matrix transpose
k = 1;

for(i=1:size(des1,1))
    flag = 0;
    
    dotprods = (ones(size(des2,1),1)*des1(i,:) - des2).^2; % Computes vector of dot products
    dotprods=sum(dotprods');
    [vals,indx] = sort(dotprods);
    s = 1;
    
    while(s<60)
        %if(vals(s) < 2*vals(s+1))
        %if(vals(s) < 2*vals(1))
        if((vals(s)-vals(1))<0.5)
            locs1(k,:) = loc1(i,:);
            matchs(k,:) = [i indx(s)];
            locs2(k,:) = loc2(indx(s),:);  k = k + 1;
        end
        s = s+1;
    end
    N(i) = s;
end

