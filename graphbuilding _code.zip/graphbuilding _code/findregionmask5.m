function I2 = findregionmask5(imm, g, loc1)

f = size(g(:,1));
[mm, nn] = size(imm);
mask = zeros(mm, nn);

for j = 1 : f

   x1 = loc1(g(j,3),2);x2 = loc1(g(j,4),2);
   y1 = loc1(g(j,3),1);y2 = loc1(g(j,4),1);
   
    yd=round(linspace(y1,y2));
    xd=round(linspace(x1,x2));
            
    for a=1:length(yd)
        mask(yd(a), xd(a)) = 255;
    end;
end
I2 = imfill(mask,'holes');


