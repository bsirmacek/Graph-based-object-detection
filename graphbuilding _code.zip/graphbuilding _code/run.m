%% DEMO CODE 
%
%  BY BERIL SIRMACEK
%  with CEM UNSALAN
%  
%  Please cite:
%  B. Sirmacek, C. Unsalan, "Urban Area and Building Detection Using SIFT Keypoints and Graph Theory", 
%  IEEE Transactions on Geoscience and Remote Sensing, Vol.47 (4), pp. 1156-1167, April 2009.
%
%  DEPENDING ON YOUR OBJECT SIZE AND THE INPUT IMAGE RESOLUTIONS, FILTERING
%  GRAPH MATCHING AND GRAPH CUT PARAMETERS MUST BE CHANGED. PLEASE REFER TO
%  THE REFERENCE ARTICLE FOR FULL DESCRIPTION OF THESE PARAMETERS AND THEIR
%  EFFECTS ON THE RESULTS.
%
%%
clear all
close all
clc
pack
warning off;
iptsetpref('ImshowBorder','tight');
 
%% READ INPUT IMAGE:

  
img1 =imread(['images/image1.jpg']);

if(size(img1,3)==3)
    img1 = rgb2gray(img1);
end

tsta=cputime;
figure, imshow(img1,[]);
%% READ 2 TEMPLATE IMAGES WHICH REPRESENT AN EXAMPLE OF THE OBJECT TO DETECT
 
time0=cputime-tsta;

tsta=cputime;
% FILTERING THE ORIGINAL IMAGE:
upr =0.8; % UPSAMPLING RATIO. TRY HIGHER NUMBER FOR SATELLITE IMAGES
img = imresize(img1, upr,'bilinear'); %img=img1;
im1 = imresize(img, upr,'bilinear'); 
w     = 5;       % bilateral filter half-width
sigma = [3 0.1]; % bilateral filter standard deviations
img1 = double(im1)/double(max(im1(:)));
bflt_img1 = bfilter2(img1,w,sigma);
img1 = 255*bflt_img1;
time1=cputime-tsta;

% FILTERING THE TEMPLATE IMAGES:
%load temp1, OUR TEMPLATES
%load temp2,
temp1 = imresize(rgb2gray(imread('images/template1.jpg')), upr, 'bilinear');
temp1 = double(temp1)/double(max(temp1(:)));
temp1 = 255*bfilter2(temp1,w,sigma);
temp2 = imresize(rgb2gray(imread('images/template2.jpg')), upr, 'bilinear');
temp2 = medfilt2(temp2, [3,3]);
temp2 = double(temp2)/double(max(temp2(:)));
temp2 = 255*bfilter2(temp2,w,sigma);

figure, imshow(temp1,[]);
figure, imshow(temp2,[]);
%%  SIFT FEATURE EXTRACTION:

tsta=cputime;
[des1, loc1] = sift(img1); % SIFT FEATURES OF THE INPUT IMAGE
[dest1, loct1] = sift(temp1); % SIFT FEATURES OF THE FIRST TEMPLATE
[dest2, loct2] = sift(temp2); % SIFT FEATURES OF THE SECOND TEMPLATE
time2=cputime-tsta;

%% MULTIPLE FEATURE MATCHING 
% !!! ORIGINAL SIFT ALGORITHM MATCHES ONLY THE MOST SIMILAR DESCRIPTORS
% HERE WE MATCH MULTIPLE DESCRIPTORS IN ORDER TO DETECT MULTIPLE OBJECTS!!!

tsta=cputime;
% match with 1st model image:
[locst1, locs1, match1, N1] = matchspecial5(dest1, des1, loct1, loc1);
showscenekeys(img1, locs1);

% match with 2nd model image:
[locst2, locs2, match2, N2] = matchspecial5(dest2, des1, loct2, loc1);
showscenekeys(img1, locs2);

% shift keys towards the buildings:
lc1 = shiftkeys(img1, locs1);
lc2 = shiftkeys(img1, locs2);

time3=cputime-tsta;
tsta=cputime;
%% CONSTRUCT GRAPHS:

[dis1] = distance2(loc1', loc1'); % GRAPH OF THE INPUT IMAGE
[distt1] = distance2(loct1', loct1'); % GRAPH OF THE FIRST TEMPLATE
[distt2] = distance2(loct2', loct2'); % GRAPH OF THE SECOND TEMPLATE

%% find residential regions:

err = 4; % KEEP THE ERROR VALUE HIGHER IF THE DISTANCE BETWEEN BUILDINGS ARE 
% TOO LARGE COMPARED TO THE LARGEST FOOTPRINT DIMENSION OF THE BUILDINGS

% find sub-graphs
g1 = makesub2(img1, distt1, dis1, loct1, loc1, match1, err);
g2 = makesub2(img1, distt2, dis1, loct2, loc1, match2, err);

region_mask1 = findregionmask3(img1, g1, loc1);
region_mask2 = findregionmask3(img1, g2, loc1);

[sx sy]=size(img);

mask = (region_mask1  | region_mask2);

drawregions2(img, imresize(mask,[sx sy],'nearest'));

time4=cputime-tsta;
clear dis1 distt1 distt2;

%% Construct graph using new locations of keys:

[s_dis1] = distance2(lc1', lc1');
[s_dis2] = distance2(lc2', lc2');

%% Cut graph to extract buildings:

tsta=cputime;
int_err = 80; % INTENSITY THRESHOLD (HOW MUCH BUILDING ROOFTOP INTENSITY 
% AND IT SURROUNDING GROUND INTENSITY CHANGE IS ALLOWED) 
dis_cut= 10; % INCREASING THIS VALUE MIGHT DETECT CLOSE BUILDINGS AS CONNECTED
g3 = nngraph(img1, s_dis1, lc1, int_err, dis_cut);
g4 = nngraph(img1, s_dis2, lc2, int_err, dis_cut);

%% Run dijkstra's algorithm and find final buildings:

% For g3:
s = max(g3(:));
wm = zeros(s, s);
for(i = 1:size(g3,1))
    a = g3(i,1);
    b = g3(i,2);
    wm(a,b) = 1;
    wm(b,a) = 1;
end
[D,P] = dijkDP(wm);

for(i = 1:size(D,1))
    d = D(i,:); p = P(i,:);
    path(i) = {dijkpath2(d,p,i)};
    clear d p;
end

  
buildingmask1 = zeros(size(img1));

for(i = 1:size(path,2))
    tmp = path{i};
    cond = 1;
    h = 1;
    if(tmp(1) > 0)
        while(cond == 1)
            a = tmp(h);
            b = tmp(h+1);
            buildingmask1=func_Drawline(buildingmask1,round(lc1(a,1)),round(lc1(a,2)),round(lc1(b,1)),round(lc1(b,2)),255);
            if(tmp(h+2)==0)
                cond = 0;
            end
            h = h + 1;
        end
            
    end
end
hold off;
clear wm i j h f path D P;
%

% For g4:
s = max(g4(:));
wm = zeros(s, s);
for(i = 1:size(g4,1))
    a = g4(i,1);
    b = g4(i,2);
    wm(a,b) = 1;
    wm(b,a) = 1;
end
[D,P] = dijkDP(wm);

for(i = 1:size(D,1))
    d = D(i,:); p = P(i,:);
    path(i) = {dijkpath2(d,p,i)};
    clear d p;
end

buildingmask2 = zeros(size(img1));

for(i = 1:size(path,2))
    tmp = path{i};
    cond = 1;
    h = 1;
    if(tmp(1) > 0)
        while(cond == 1)
            a = tmp(h);
            b = tmp(h+1);
            buildingmask2=func_Drawline(buildingmask2,round(lc2(a,1)),round(lc2(a,2)),round(lc2(b,1)),round(lc2(b,2)),255);
            if(tmp(h+2)==0)
                cond = 0;
            end
            h = h + 1;
        end
            
    end
end
hold off;
clear wm i j h f path D P;


buildingmask = (buildingmask1 | buildingmask2);
figure, imshow(buildingmask);
se = strel('disk',1);
mask3 = imdilate(buildingmask,se);
figure, imshow(mask3)
mask4 = bwareaopen(mask3,100);


bl=bwlabel(mask4);
[sx,sy]=size(mask4);
time5=cputime-tsta;

% possible building centers:
figure, imshow(img,[]); hold on;
for a=1:max(bl(:))
 
    level=bl==a;
    [k,l]=find(level);
    mk=mean(k)/upr;
    ml=mean(l)/upr;
    du=plot(ml,mk,'ks');
    set(du,'markersize',10);
    set(du,'markerfacecolor','y');

end
hold off;

% buildings are found at:
figure, imshow(img,[]); hold on;
[x,y] = find(buildingmask);
plot(y./upr,x./upr,'.r');


timetable=[time1;time2;time3;time4;time5]
sum(timetable)

%% 



