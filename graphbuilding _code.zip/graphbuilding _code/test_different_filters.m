

im = imread('images\ada_3_1_1_pans.tif');
im1 = (double(im)*255)/65535; clear im;
im1 = imresize(im1,3);

temp = imcrop(im1, [910, 329, 79, 67]);

%% preprocess:


%bilateral:
w     = 5;       % bilateral filter half-width
sigma = [3 0.1]; % bilateral filter standard deviations
img1 = double(im1./max(max(im1)));
bflt_img1 = bfilter2(img1,w,sigma);
img1 = 255*bflt_img1;

temp_bilateral = imcrop(img1, [910, 329, 79, 67]);

% median:
temp_med = ordfilt2(temp,5,ones(3,3)) 
figure, mesh(temp_med);

% max filter:
temp_max = ordfilt2(temp,9,ones(3,3)) 
figure, mesh(temp_max);

% min filter:
temp_min = ordfilt2(temp,1,ones(3,3)) 
figure, mesh(temp_min);

% gaussian:
PSF = fspecial('gaussian',8,3);
temp_gauss = imfilter(temp,PSF,'conv');
figure, mesh(temp_gauss);


%%