


%% preprocess:
% 
im1 = (double(img1)*255)/65535; clear img1,

%bilateral:
im1 = imresize(im1,6,'bilinear');
w     = 5;       % bilateral filter half-width
sigma = [3 0.1]; % bilateral filter standard deviations
img1 = double(im1)/max(im1(:));
bflt_img1 = bfilter2(img1,w,sigma);
img1 = 255*bflt_img1;

% load img8,
load temp1,
load temp2,

figure, imshow(img1, []);
figure, imshow(temp1, []);
figure, imshow(temp2, []);


%%  sift:

[des1, loc1] = sift(img1);
[dest1, loct1] = sift(temp1);
[dest2, loct2] = sift(temp2);

%% multiple matching:

% match with 1st model image:
[locst1, locs1, match1, num1] = matchspecial(dest1, des1, loct1, loc1, 60);
showscenekeys(img1, locs1);

% match with 2nd model image:
[locst2, locs2, match2, num2] = matchspecial(dest2, des1, loct2, loc1, 60);
showscenekeys(img1, locs2);

% shift keys towards the buildings:
lc1 = shiftkeys(img1, locs1);
lc2 = shiftkeys(img1, locs2);
% lct1 = shiftkeys(temp1, locst1);
% lct2 = shiftkeys(temp2, locst2);

%% construct graph:

[dis1] = distance2(loc1', loc1');
[distt1] = distance2(loct1', loct1');
[distt2] = distance2(loct2', loct2');

%% find residential regions:

err = 4;
% find sub-graphs
g1 = makesub2(img1, distt1, dis1, loct1, loc1, match1, err);
g2 = makesub2(img1, distt2, dis1, loct2, loc1, match2, err);

region_mask1 = findregionmask3(img1, g1, loc1);
region_mask2 = findregionmask3(img1, g2, loc1);

mask = (region_mask1  | region_mask2);
%figure, imshow((1-mask),[]);
drawregions2(img1, mask);

clear dis1 distt1 distt2;
%% calculate residential region error:

% manual = imread('adana8_residential.tif');
% manual = (double(manual)*255)/65535; 
% manual = imresize(manual,6);
% 
% for(i = 1:size(manual,1))
%     for(j = 1:size(manual,2))
%         if(manual(i,j)==255)
%             manual(i,j) = 0;
%         else
%             manual(i,j) = 1;
%         end
%     end
% end
% 
% manual = im2bw(imfill(manual,'holes'));
% totalregion = size(find(manual==1),1);
% 
% a = 2*manual-mask;
% tp = 0; fp = 0;
% for(i = 1:size(a,1))
%     for(j = 1:size(a,2))
%         if(a(i,j) == 1)
%             tp = tp + 1;
%         elseif(a(i,j) == -1)
%             fp = fp + 1;
%         end
%     end
% end
% 
% disp('true positives:');
% tp = tp/totalregion
% 
% disp('false positives:');
% fp = fp/totalregion

%% construct graph using new locations of keys:

[s_dis1] = distance2(lc1', lc1');
[s_dis2] = distance2(lc2', lc2');

%% cut graph to extract buildings:

% figure, imshow(img1,[]);hold on,
% plot(lc1(:,2), lc1(:,1), '.r'); hold on;
% plot(lc2(:,2), lc2(:,1), '.g'); hold off;

int_err = 80;
g3 = nngraph(img1, s_dis1, lc1, int_err);
g4 = nngraph(img1, s_dis2, lc2, int_err);

%% Run dijkster's algorithm and find final buildings:

% For g3:
s = max(max(g3));
wm = zeros(s, s);
for(i = 1:s)
    a = find(g3(:,1)==i);
    if(isempty(a) == 0)
        for(j = 1:size(a,1))
            b = g3(a(j),2);
            wm(i,b) = 1;
        end
    end
end
clear a b,
h = 1;
dijgraph = dijkDP(wm);
for(i = 1:s)
    a = max(dijgraph(i,:));
    if(a >= 3)
        b = find(g3(:,1)==i);
        for(j = 1:size(b,1)) 
            g5(h,:) = g3(b(j),:); h = h+1;
        end
    end
end
figure, imshow(img1, []); hold on,
buildingmask1 = zeros(size(img1));
if (h>1)
    f = size(g5,1);   
    for (j = 1 : f)       
        plot(lc1(g5(j,1),2), lc1(g5(j,1),1), '.b');
        hold on;
        plot(lc1(g5(j,2),2),lc1(g5(j,2),1), '.b');
        hold on;
        line([lc1(g5(j,1),2) lc1(g5(j,2),2)], ...
         [lc1(g5(j,1),1) lc1(g5(j,2),1)], 'Color', 'r', 'LineWidth', 4);
         hold on;
        buildingmask1=func_Drawline(buildingmask1,round(lc1(g5(j,1),1)),round(lc1(g5(j,1),2)),...
            round(lc1(g5(j,2),1)),round(lc1(g5(j,2),2)),255);
    end
end
hold off;
clear wm i j h f;
%

% For g4:
s = max(max(g4));
wm = zeros(s, s);
for(i = 1:s)
    a = find(g4(:,1)==i);
    if(isempty(a) == 0)
        for(j = 1:size(a,1))
            b = g4(a(j),2);
            wm(i,b) = 1;
        end
    end
end
clear a b,
h = 1;
dijgraph = dijkDP(wm);
for(i = 1:s)
    a = max(dijgraph(i,:));
    if(a >= 3)
        b = find(g3(:,1)==i);
        for(j = 1:size(b,1)) 
            g6(h,:) = g4(b(j),:); h = h+1;
        end
    end
end
figure, imshow(img1, []); hold on,
buildingmask2 = zeros(size(img1));
if (h>1)
    f = size(g6,1);   
    for (j = 1 : f)       
        plot(lc2(g6(j,1),2), lc2(g6(j,1),1), '.b');
        hold on;
        plot(lc2(g6(j,2),2),lc2(g6(j,2),1), '.b');
        hold on;
        line([lc2(g6(j,1),2) lc2(g6(j,2),2)], ...
         [lc2(g6(j,1),1) lc2(g6(j,2),1)], 'Color', 'r', 'LineWidth', 4);
         hold on;
        buildingmask2=func_Drawline(buildingmask2,round(lc2(g6(j,1),1)),round(lc2(g6(j,1),2)),...
            round(lc2(g6(j,2),1)),round(lc2(g6(j,2),2)),255);
    end
end
hold off;
clear wm i j h f;
%

buildingmask = (buildingmask1 | buildingmask2);

se = strel('disk', 6);
mask3 = imdilate(buildingmask,se);
figure, imshow(mask3,[]);
mask4 = bwareaopen(mask3,1000);
figure, imshow(mask4,[]);
mask3 = mask4;

bl=bwlabel(mask3);
[sx,sy]=size(mask3);
% final=255*ones(sx,sy);
% final(1:5,:)=0; final(sx-5:sx,:)=0;
% final(:,1:5)=0; final(:,sy-5:sy)=0;
% imshow(final,[]);hold on;

figure, imshow(img1,[]); hold on;

for a=1:max(bl(:))
    level=bl==a;
    [k,l]=find(level);
    mk=mean(k);
    ml=mean(l);
    du=plot(ml,mk,'ks');
    set(du,'markersize',20);
    set(du,'markerfacecolor','red');
end
hold off;

%% calculate building error:
% 
% manual = imread('adana8_buildings.tif');
% manual = (double(manual)*255)/65535; 
% manual = imresize(manual,6,'nearest');
% 
% for(i = 1:size(manual,1))
%     for(j = 1:size(manual,2))
%         if(manual(i,j)>250)
%             manual(i,j) = 0;
%         else
%             manual(i,j) = 1;
%         end
%     end
% end
% 
% manual = im2bw(imfill(manual,'holes'));
% manual = bwareaopen(manual,3000);
% [r,num] = bwlabel(manual);
% 
% a = (manual&mask3);
% [r,tp] = bwlabel(a);
% 
% [r,f] = bwlabel(mask3);
% fp = f-num;
% 
% disp('true positives:');
% tp = tp/num
% 
% disp('false positives:');
% fp = fp/num

%%














