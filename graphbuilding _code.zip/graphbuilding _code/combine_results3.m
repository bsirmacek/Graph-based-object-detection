clear all
close all
clc
warning off;
iptsetpref('ImshowBorder','tight');
 
imgt=[];

%fixc=450; imnum=[1:7 9:11];

%fixc=300; imnum=[1:7 9:11];
fixc=300; imnum=[12:19];
%fixc=300; imnum=[1:5];


rowline=255*ones(3,3*fixc+6,3);

for in=imnum
    
img1 =imread(['results3/adana' num2str(in) '.tif']);
img2 =imread(['results3/adana' num2str(in) '_residential.tif']);
img3 =imread(['results3/adana' num2str(in) '_buildings.tif']);

% img1 =imread(['results3/ankara' num2str(in) '.tif']);
% [sx,sy,sz]=size(img1);du=zeros(sx,sy,3);
% if sz==1
%     du(:,:,1)=img1;du(:,:,2)=img1;du(:,:,3)=img1;img1=du;
% end;
% img2 =imread(['results3/ankara' num2str(in) '_residential.tif']);
% img3 =imread(['results3/ankara' num2str(in) '_buildings.tif']);

img1=imresize(img1,[nan fixc]);

[sx,sy,sz]=size(img1);

img2=imresize(img2,[sx sy]);
img3=imresize(img3,[sx sy]);

colline=255*ones(sx,3,sz);

if sum(imgt(:,:,:))
imgt=[imgt; rowline;img1 colline img2 colline img3];
else
imgt=[img1 colline img2 colline img3];
end;

end;%for imnum


% fixc=300; imnum=[1:4];
% 
% for in=imnum
%     
% img1 =imread(['results3/istanbul' num2str(in) '.tif']);
% [sx,sy,sz]=size(img1);du=zeros(sx,sy,3);
% if sz==1
%     du(:,:,1)=img1;du(:,:,2)=img1;du(:,:,3)=img1;img1=du;
% end;
% img2 =imread(['results3/istanbul' num2str(in) '_residential.tif']);
% img3 =imread(['results3/istanbul' num2str(in) '_buildings.tif']);
% 
% 
% img1=imresize(img1,[nan fixc]);
% 
% [sx,sy,sz]=size(img1);
% 
% img2=imresize(img2,[sx sy]);
% img3=imresize(img3,[sx sy]);
% 
% colline=255*ones(sx,3,sz);
% 
% if sum(imgt(:,:,:))
% imgt=[imgt; rowline;img1 colline img2 colline img3];
% else
% imgt=[img1 colline img2 colline img3];
% end;
% 
% end;%for imnum




imshow(imgt);
