clear all
close all
clc
warning off;
iptsetpref('ImshowBorder','tight');
 
%for count=2:19 
%for count=[2 6 14] 
for count=8 
    close all;pause(0.01);
    
imname = ['adana' num2str(count)];

disp(imname)
pause(0.01);

img =imread(['images\' imname '.tif']);

if(max(img(:)))>255
    img=double(img);
    img=uint8(img/2^8);
end;


%% preprocess:
im1 = imresize(double(img),6,'bilinear');

%bilateral:
w     = 5;       % bilateral filter half-width
sigma = [3 0.1]; % bilateral filter standard deviations
im1 = im1/max(im1(:));
bflt_im1 = bfilter2(im1,w,sigma);
im1 = 255*bflt_im1;

load temp1;load temp2;

%%  sift:

[des1, loc1] = sift(im1);
[dest1, loct1] = sift(temp1);
[dest2, loct2] = sift(temp2);

%% multiple matching:

% match with 1st model image:
[locst1, locs1, match1, num1] = matchspecial(dest1, des1, loct1, loc1, 60);

% match with 2nd model image:
[locst2, locs2, match2, num2] = matchspecial(dest2, des1, loct2, loc1, 60);

% shift keys towards the buildings:
lc1 = shiftkeys(im1, locs1);
lc2 = shiftkeys(im1, locs2);

%% construct graph:
[dis1] = distance2(loc1', loc1');
[distt1] = distance2(loct1', loct1');
[distt2] = distance2(loct2', loct2');

%% find residential regions:

err = 4;
% find sub-graphs
g1 = makesub2(im1, distt1, dis1, loct1, loc1, match1, err);
g2 = makesub2(im1, distt2, dis1, loct2, loc1, match2, err);

region_mask1 = findregionmask3(im1, g1, loc1);
region_mask2 = findregionmask3(im1, g2, loc1);

%region_mask1 = findregionmask5(im1, g1, loc1);
%region_mask2 = findregionmask5(im1, g2, loc1);

[sx sy]=size(img);

mask = region_mask1 | region_mask2;

mask=imresize(mask,[sx sy],'nearest');

[k,l]=find(edge(uint8(mask)));

for a=1:length(k)
    img(k(a),l(a))=253;
end;%for a

imwrite(mask,['results\' imname '_res.tif'],'tiff');
%imwrite(img,['results\' imname '_mask.tif'],'tiff');

end;%for count

