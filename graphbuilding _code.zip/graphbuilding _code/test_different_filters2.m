clear
close all

iptsetpref('ImshowBorder','tight');
 
img = imread('images\adana8_zoom.tif');
%img = imread('images\adana8.tif');


%% preprocess:
im1 = imresize(double(img),6,'nearest');

figure;imshow(im1,[]);
%figure;mesh(im1);

%bilateral:
w     = 5;       % bilateral filter half-width
sigma = [3 0.1]; % bilateral filter standard deviations
bflt_im1 = bfilter2(im1/max(im1(:)),w,sigma);
imgb = 255*bflt_im1;

figure;imshow(imgb,[]);
%figure;mesh(imgb);

% gaussian:
PSF = fspecial('gaussian',8,3);
imgg = imfilter(im1,PSF,'conv');

figure;imshow(imgg,[]);
%figure;mesh(imgg);

% min filter:
imgmin = ordfilt2(im1,1,ones(3,3)); 

figure;imshow(imgmin,[]);
%figure;mesh(imgmin);

% median:
imgmed = ordfilt2(im1,5,ones(3,3)); 

figure;imshow(imgmed,[]);
%figure;mesh(imgmed);

% max filter:
imgmax = ordfilt2(im1,9,ones(3,3)); 

figure;imshow(imgmax,[]);
%figure;mesh(imgmax);

