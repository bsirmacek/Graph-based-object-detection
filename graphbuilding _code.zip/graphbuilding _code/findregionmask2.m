
function [I2] = findregionmask2(imm, g, locs1, thresh)

f = size(g,2);
[mm, nn] = size(imm);
mask = zeros(mm, nn);

for (j = 1 : f)
    [newmask] = findregionmask3(imm, g, locs1);
    mask = mask + newmask;
end

for (i = 1:mm)
    for (j = 1:nn)
        if (mask(i,j)<thresh)
            mask(i,j) = 0;
        end
    end
end

m = max(max(mask));
mask2 = (mask.*255)./m;

%figure, imshow(mask2,[]);
%figure, mesh(mask2);
se = strel('disk',5);
a = imerode(mask2, se1, 'same');

se1 = strel('disk',11);
ii = imdilate(a, se1, 'same');
i2 = imfill(ii,'holes');
%figure, imshow(i2,[]);

se = strel('square',12);
I2 = imopen(i2, se);

figure, imshow(I2,[]);






