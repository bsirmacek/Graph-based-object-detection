
function [I2] = findregionmask(im2, g2, loc)

f = size(g2(:,1));
[mm, nn] = size(im2);
mask = zeros(mm, nn);

for (j = 1 : f)
    if(loc(g2(j,3),2) < loc(g2(j,4),2))
        x1 = loc(g2(j,3),2);
        x2 = loc(g2(j,4),2);
    else
        x1 = loc(g2(j,4),2); %x1 is always smaller one
        x2 = loc(g2(j,3),2); 
    end
    if(loc(g2(j,3),1) < loc(g2(j,4),1))
        y1 = loc(g2(j,3),1);
        y2 = loc(g2(j,4),1);
    else
        y1 = loc(g2(j,4),1); % y1 is always smaller one
        y2 = loc(g2(j,3),1);
    end
    x1 = round(x1); x2 = round(x2);
    y1 = round(y1); y2 = round(y2);
    mask(y1:y2, x1:x2) = 255;
end

% fill holes
%se = strel('ball',10,10);
%mask = imdilate(mask,se);
se1 = strel('line',6,0);
se2 = strel('line',6,90);
ii = imdilate(mask,[se1 se2],'same');
I2 = imfill(ii,'holes');
%I2 = (255-I);

% figure, imshow(I2, []);title('region mask');