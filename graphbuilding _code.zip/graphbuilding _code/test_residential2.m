clear all
close all
clc
warning off;
iptsetpref('ImshowBorder','tight');
 
total=[];

for count=1:19 
%for count=1:5 
%for count=1:4 

imname = ['adana' num2str(count)];
%imname = ['ankara' num2str(count)];
%imname = ['istanbul' num2str(count)];

mask =imread(['results4\' imname '_mask.tif']);
[sx sy]=size(mask);

res =imread(['results4\' imname '_res.tif']);res = imresize(res, [sx sy],'nearest');

%res =imread(['results\' imname '_res1.tif']);res=imresize(res,[sx sy],'nearest');
%res =imread(['results\' imname '_res2.tif']);res=imresize(res,[sx sy],'nearest');
%res =imread(['results\' imname '_res3.tif']);res=imresize(res,[sx sy],'nearest');
%res =imread(['results\' imname '_res4.tif']);res=imresize(res,[sx sy],'nearest');
%res =imread(['results\' imname '_res5.tif']);res=imresize(res,[sx sy],'nearest');
%res =imread(['results\' imname '_res6.tif']);res=imresize(res,[sx sy],'nearest');

 mask=mask>100;

%  imshow(mask,[]);
%  (num2str(max(mask(:))))
%  pause

detected=imdilate(res,ones(9,9))&mask;
%detected=imdilate(res,ones(6,6))&mask;
missed=mask&(~imdilate(res,ones(6,6)));
falarm=res&(~mask);

%du=[1 sx sy sum(mask(:)) sum(detected(:)) sum(missed(:)) sum(falarm(:))];
du=[count sx sy sum(mask(:)) sum(detected(:)) sum(falarm(:)) sum(detected(:))/sum(mask(:))*100 sum(falarm(:))/sum(mask(:))*100];
total=[total;du];

end;%for count

total
%xlswrite('tablo1.xls',total);
%xlswrite('tablo2.xls',total);
%xlswrite('tablo3.xls',total);
