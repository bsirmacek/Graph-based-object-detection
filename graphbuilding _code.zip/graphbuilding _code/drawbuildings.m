


function drawbuildings(img1, g4, lc1)


s = max(g4(:,1)');

t = 1;

for (i = 1:s)
    
    a = find(g4(:,1)==i);
    
    if(isempty(a) == 0) %if it is not an empty matrix
        
        for(j = 1: size(a,1))
            c(j,:) = g4(a(j),:);
        end
        
        building(t) = {c}; t = t+1;
        
    end
    
    clear c a;
end


%%

figure, imshow(img1,[]); hold on,

for (i = 1:size(building,2))
    
    c = building{i};
    
    d = [c(1,1);c(:,2)];
    e = circshift(d,1);
    
    plot(round(lc1(d(:),2)), round(lc1(d(:),1)), '.b', 'LineWidth',6); hold on,
    
    
    f1 = round(lc1(d(:),2))';
    f2 = round(lc1(e(:),2))';
    
    eq = isequal(f1,f2);
    
    if(eq == 0)
        if(size(c,1)>2)
            k = convhull(lc1(d(:),2),lc1(d(:),1));
            plot(lc1(d(k),2),lc1(d(k),1),'b', 'LineWidth',6), hold on,
        end
    end
    
        clear c d f k eq f1 f2 e;

end


%%









