function path=dijkpath(D,P)

[sx,sy]=size(D);

path=zeros(sx,sy);

for ind=1:sx
%ind
[val,pl]=max(D(ind,:));

if val>=3
    cond=1;
path(ind,1)=pl;
i=2;
    while cond
        pl=P(ind,pl);
        if pl==ind
            cond=0;
        else
            path(ind,i)=pl;i=i+1;
        end;
    end;%while
    path(ind,i) = ind;
end;%if
end;%for ind