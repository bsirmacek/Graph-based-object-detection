

function findurban_sift(img1)


%% load templates:

load temp1,
load temp2,

%%  sift:

[des1, loc1] = sift(img1);
[dest1, loct1] = sift(temp1);
[dest2, loct2] = sift(temp2);

%% multiple matching:
% match with 1st model image:
[locst1, locs1, match1, N1] = matchspecial5(dest1, des1, loct1, loc1);
showscenekeys(img1, locs1);

% match with 2nd model image:
[locst2, locs2, match2, N2] = matchspecial5(dest2, des1, loct2, loc1);
showscenekeys(img1, locs2);

% shift keys towards the buildings:
lc1 = shiftkeys(img1, locs1);
lc2 = shiftkeys(img1, locs2);
%% construct graph:

[dis1] = distance2(loc1', loc1');
[distt1] = distance2(loct1', loct1');
[distt2] = distance2(loct2', loct2');

%% find residential regions:

err = 4;
% find sub-graphs
g1 = makesub2(img1, distt1, dis1, loct1, loc1, match1, err);
g2 = makesub2(img1, distt2, dis1, loct2, loc1, match2, err);

region_mask1 = findregionmask3(img1, g1, loc1);
region_mask2 = findregionmask3(img1, g2, loc1);

[sx sy]=size(img);

mask = (region_mask1  | region_mask2);

drawregions2(img, imresize(mask,[sx sy],'nearest'));
clear dis1 distt1 distt2;

%% 



