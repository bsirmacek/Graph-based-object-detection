function [locs1, locs2, matchs, N] = matchspecial3(des1, des2, loc1, loc2)

N=0;
% For each descriptor in the first image, select its match to second image.
des2t = des2';      % Precompute matrix transpose

k = 1;
num = 0;
h=1;


for(i=1:size(des1,1))
    flag = 0;
    
    dotprods = (ones(size(des2,1),1)*des1(i,:) - des2).^2; % Computes vector of dot products
    dotprods=sum(dotprods');
    [vals,indx] = sort(dotprods);
    %
    locs1(k,:) = loc1(i,:);
    matchs(k,:) = [i indx(1)];
    locs2(k,:) = loc2(indx(1),:); k = k+1;
    
    for(s = 2:size(des2,1))
        if(flag == 0)     
            if((vals(s)-vals(1)) < 0.5)
                
                locs1(k,:) = loc1(i,:);
                matchs(k,:) = [i indx(s)];
                locs2(k,:) = loc2(indx(s),:); k = k+1;   
                N(i) = s;
            else
                flag = 1;  
            end
        end
    end 
    
    if(N(i)>60)
        N(i) = 60;
    end
    
end



%eliminate keys if they are found in different scales but in the same
%location cause i need only locs of nodes after matching has been done.
% [rlocs1, rlocs2, rmatchs, rnum] = reducekey(locs1, locs2, matchs, num); 