

function drawregions3(imm, building_mask)


%[B,L] = bwboundaries(building_mask,'noholes');

figure, imshow(imm, []);%title('Traced');
hold on,

for (i = 1:size(building_mask,1))
    for(j = 1:size(building_mask,2))
        if(building_mask(i,j)>200)
            mask(i,j) = 1;
        else
            mask(i,j) = 0;
        end
    end
end

mask = bwareaopen(mask,3000);
se = strel('disk',10);
mask = imerode(mask,se);
se = strel('disk',20);
mask = imdilate(mask,se);

[B,L,N,A] = bwboundaries(mask);
       for k=1:length(B),
         if(~sum(A(k,:)))
           boundary = B{k};
           plot(boundary(:,2), boundary(:,1), 'y','LineWidth',6);
%            for l=find(A(:,k))'
%              boundary = B{l};
%              plot(boundary(:,2), boundary(:,1), 'g','LineWidth',13);
%            end
         end
       end
       
% for k = 1:length(B)
%   boundary = B{k};
%   plot(boundary(:,2), boundary(:,1), 'y', 'LineWidth', 12);
% end
hold off





