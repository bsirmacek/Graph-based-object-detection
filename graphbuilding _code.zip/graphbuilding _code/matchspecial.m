function [locs1, locs2, matchs, num] = matchspecial(des1, des2, loc1, loc2, desnum)


% For each descriptor in the first image, select its match to second image.
des2t = des2';      % Precompute matrix transpose

k = 1;
num = 0;

for i = 1 : size(des1,1)
    dotprods = des1(i,:) * des2t;        % Computes vector of dot products
    [vals,indx] = sort(acos(dotprods));  % Take inverse cosine and sort results
    % store best 5 matchs:
    for(s = 1:desnum)
        if(vals(s) < 2.4*vals(s+1))
            locs1(k,:) = loc1(i,:);
            matchs(k,:) = [i indx(s)];
            locs2(k,:) = loc2(indx(s),:); k = k+1;
            num = num + 1;
        end
    end
    
end

%eliminate keys if they are found in different scales but in the same
%location cause i need only locs of nodes after matching has been done.
% [rlocs1, rlocs2, rmatchs, rnum] = reducekey(locs1, locs2, matchs, num); 