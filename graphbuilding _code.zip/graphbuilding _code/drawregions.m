

function drawregions(img, m)

bw2 = bwareaopen(m,400);

[B,L] = bwboundaries(bw2,'noholes');

figure, imshow(img, []);%title('Traced');
hold on,

for k = 1:length(B)
  boundary = B{k};
  plot(boundary(:,2), boundary(:,1), 'r', 'LineWidth', 3);
end

% for (w = 1:num)
%     x = 0; y = 0;
%     [y,x] = find(L==w);
%     bw = imadjust(mask, stretchlim(mask),[]);
%     level = graythresh(bw);
%     BWJ = im2bw(bw,level);
%     dim = size(BWJ)
%     IN=ones(dim(1),dim(2));
%     BW=xor(BWJ,IN);  %inverting
%     %Finding of initial point
%     row = round(dim(1)/2);
%     col = min(find(BW(row,:)))
%     %Tracing
%     boundary = bwtraceboundary(BW,[row, col],'W');
%     %Display traced boundary
%     plot(boundary(:,2),boundary(:,1),'g','LineWidth',2);
% end

hold off





% for (w = 1:num)
%     x = 0; y = 0;
%     [y,x] = find(L==w);
%         k = convhull(x ,y ,{'Qt','Pp'});
%         plot(x(k), y(k), '-r');
%         hold on,
% end
% hold off,


