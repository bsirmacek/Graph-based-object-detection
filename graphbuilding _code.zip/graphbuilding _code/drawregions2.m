

function drawregions2(imm, building_mask)


figure, imshow(imm, []);%title('Traced');
hold on,

[B,L,N,A] = bwboundaries(building_mask);

for k=1:length(B),
    if(~sum(A(k,:)))
        boundary = B{k};
        plot(boundary(:,2), boundary(:,1),'y','LineWidth',3);
%        plot(boundary(:,2), boundary(:,1),'y','LineWidth',2);
    end
end
       
hold off;


