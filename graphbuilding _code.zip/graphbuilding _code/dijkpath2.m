function path=dijkpath2(d2, p2, ind)


path=zeros(size(d2));

[val,pl]=max(d2);

if val>=3
    cond=1;
    path(1)=pl;
    i=2;
    while cond
        pl=p2(pl);
        if pl==ind
            cond=0;
        else
            path(i)=pl; i=i+1;
        end;
    end;%while
    path(i) = ind;
end;%if