
function [I2] = findregionmask4(imm, g, loc1)


f = size(g(:,1));
[mm, nn] = size(imm);
mask = zeros(mm, nn);

for (j = 1 : f)
    if(loc1(g(j,1),2) < loc1(g(j,2),2))
        x1 = loc1(g(j,1),2);
        x2 = loc1(g(j,2),2);
    else
        x1 = loc1(g(j,2),2); %x1 is always smaller one
        x2 = loc1(g(j,1),2); 
    end
    if(loc1(g(j,1),1) < loc1(g(j,2),1))
        y1 = loc1(g(j,1),1);
        y2 = loc1(g(j,2),1);
    else
        y1 = loc1(g(j,2),1); % y1 is always smaller one
        y2 = loc1(g(j,1),1);
    end
    x1 = round(x1); x2 = round(x2);
    y1 = round(y1); y2 = round(y2);
    mask(y1:y2, x1:x2) = 255;
end

se = strel('ball', 10, 10);
% %mask = imdilate(mask,se);
% se1 = strel('line',6,0);
% se2 = strel('line',6,90);
ii = imdilate(mask,se,'same');
I2 = imfill(ii,'holes');
% %I2 = (255-I);

figure, imshow(I2, []);