
function [mask] = showregions(im, tempcell)

%% Read templates

k = size(tempcell,1); % number of template images

%% Apply pre-processing to the original image and to templates

% For image:
img2 = (double(im)*255)/65535; %convert 16bit image to 8bit 256 grayscale
%figure, imshow(img2,[]);title('sat image - 1');

% i2 = medfilt2(img2, [3 3]);  % apply median filtering to reject small changes
% % i2 = localnormalize(ii, 3, 3);    % illumination normalization
% %figure, imshow(i2,[]);
% 
% % m1 = max(max(i2));
% % n1 = min(min(i2));
% % imm = 255.*((i2-n1)./(m1-n1)); %contrast streching
% 
% % h = fspecial('laplacian',1);
% % n2 = imfilter(imm,h,'replicate');
% % 
% % i3 = 0.5.*abs(n2)+imm;
% % mm = max(max(i3));
% % nn = min(min(i3));
% % im2 = 255.*((i3-nn)./(mm-nn));  
% %figure, imshow(im2,[]);
im2 = preprocess(img2);

%clear h i2 i3 im imm m1 n1 n2 nn mm ii;

% For Templates:

for (i = 1:k)
    t = tempcell{i,1}; 
    temp = (double(t)*255)/65535; %convert 16bit image to 8bit 256 grayscale
    i2 = medfilt2(temp, [3 3]);  % apply median filtering to reject small changes
%     m1 = max(max(i2));
%     n1 = min(min(i2));
%     imm = 255.*((i2-n1)./(m1-n1)); %contrast streching
%     h = fspecial('laplacian',1);
%     n2 = imfilter(imm,h,'replicate');
%     i3 = 0.5.*abs(n2)+imm;
%     mm = max(max(i3));
%     nn = min(min(i3));
%     tt = 255.*((i3-nn)./(mm-nn)); 
    tt=preprocess(i2);
    tmp_filtered(i,1) = {tt};
    tmp_org(i,1) = {temp};
    %clear h i2 i3 im imm m1 n1 n2 nn mm ii t tt temp;
end

%% Find SIFT keys

% For original image:
    [des2, loc2] = sift(im2);
    showkeys(img2, loc2); title('sat image with key points');
    
% For templates:
for (i = 1:k) 
    t = tmp_org{i,1};
    tt = tmp_filtered{i,1};
    [des, loc] = sift(tt);
    showkeys(t, loc); title('sat image with key points');
    tmp_des(i,1) = {des};
    tmp_loc(i,1) = {loc};
    clear t tt;
end

%% Match template and image features by looking at vector similarities

for (i = 1:k)
    des1 = tmp_des{i,1};
    loc1 = tmp_loc{i,1};
    % [locs1, locs2, match, num] = matchspecial(des1, des2, loc1, loc2, 55);
    [locs1, locs2, match, num] = matchspecial(des1, des2, loc1, loc2, 35);
    showscenekeys(img2, locs2);
    tmp_locs(i,1) = {locs1};
    tmp_match(i,1) = {match}; 
    tmp_num(i,1) = {num};
    clear des1 loc1 locs1 match num;
end

%% Find combined features

%% Calculate pixel distances of keys

% For template:
for (i = 1:k)
    loc = tmp_loc{i,1};
    [dist] = distance(loc', loc');
    tmp_dist(i,1) = {dist};
    clear loc dist;
end

% For original image:
[dist2] = distance(loc2', loc2');

%% Find 1 edge subgraph

 err = 4;
% err = 8;

% find sub-graphs
for (i = 1:k)
    dist = tmp_dist{i,1};
    loc1 = tmp_loc{i,1};
    match = tmp_match{i,1};
    [g2, mask] = makesub2(img2, dist, dist2, loc1, loc2, match, err);
    tmp_g2(i,1) = {g2};
    tmp_mask(i,1) = {mask};
    clear dist loc1 match g2 mask;
end

%% Draw regions

for (i = 1:k)
    g2 = tmp_g2{i,1};
    %mask = tmp_mask{i,1};
    [mask] = findregionmask(img2, g2, loc2);
    drawregions(img2, mask);
end

%% 


