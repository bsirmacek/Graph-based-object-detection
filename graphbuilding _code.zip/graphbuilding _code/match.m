

function [num, matched, notmatched] = match(img1, img2, desc1, desc2, locs1, locs2)


distRatio = 2;   
   
h = 1;
notmatched(1,:) = [0 0];

% For each descriptor in the first image, select its match to second image.
des2t = desc2';                          % Precompute matrix transpose
for i = 1 : size(desc1,1)
   dotprods = desc1(i,:) * des2t;        % Computes vector of dot products
   [vals,indx] = sort(acos(dotprods));  % Take inverse cosine and sort results

   % Check if nearest neighbor has angle less than distRatio times 2nd.
   if (vals(1) < distRatio * vals(2))
      matchs(i) = indx(1);
   else
      matchs(i) = 0;
      notmatched(h , :) = [locs1(i,2) locs1(i,1)];
      h = h + 1;
   end
end

% Create a new image showing the two images side by side.
im3 = appendimages(img1,img2);

% Show a figure with lines joining the accepted matches.
figure('Position', [100 100 size(im3,2) size(im3,1)]);
colormap('gray');
fig1 = imagesc(im3);
hold on;
cols1 = size(img1,2);
for i = 1: size(desc1,1)
  if (matchs(i) > 0)
    line([locs1(i,2) locs2(matchs(i),2)+cols1], ...
         [locs1(i,1) locs2(matchs(i),1)], 'Color', 'c');
    
     x1(i) = locs1(i,2);
     x2(i) = locs2(matchs(i),2);
     y1(i) = locs1(i,1);
     y2(i) = locs2(matchs(i),1);
  end
end
%hold off;

num = sum(matchs > 0);
fprintf('Found %d matches.\n', num);


% display match points:
matched = [x1', y1', x2', y2'];

if (notmatched(1,:) == [0 0])
    disp('all the keys in the template are matched with the keys in the scene image...');
else
    disp('there are some unmatched keys in the template image...');
end











