

function [locs1, locs2, matchs, N] = matchspecial3(des1, des2, loc1, loc2)

N=0;
% For each descriptor in the first image, select its match to second image.
des2t = des2';      % Precompute matrix transpose
k = 1;
h = 1;

for(i=1:size(des1,1))
    flag = 0;
    
    dotprods = (ones(size(des2,1),1)*des1(i,:) - des2).^2; % Computes vector of dot products
    dotprods=sum(dotprods');
    [vals,indx] = sort(dotprods);

    tmp = vals-vals(1);
    t = find(tmp < 0.5);
    n = size(t,2);
    
%    if(n>60)
%        n = 60;
%    end

    if(n>100)
        n = 100;
    end


for(j = 1:n)
        locs1(k,:) = loc1(i,:);
        matchs(k,:) = [i indx(j)];
        locs2(k,:) = loc2(indx(j),:); k = k+1;   
    end
    N(i) = n;
end

