
function mask = drawrec2(g3, loc, im)

f = size(g3(:,1));
mask = zeros(size(im));


for (j = 1 : f)
    if(loc(g3(j,3),2) < loc(g3(j,4),2))
        x1 = loc(g3(j,3),2);
        x2 = loc(g3(j,4),2);
    else
        x1 = loc(g3(j,4),2); %x1 is always smaller one
        x2 = loc(g3(j,3),2); 
    end
    if(loc(g3(j,3),1) < loc(g3(j,4),1))
        y1 = loc(g3(j,3),1);
        y2 = loc(g3(j,4),1);
    else
        y1 = loc(g3(j,4),1); % y1 is always smaller one
        y2 = loc(g3(j,3),1);
    end
    mask(y1:y2,x1:x2) = 1;
    %rectangle('position', [x1, y1, (x2-x1+1), (y2-y1+1)], 'facecolor', 'y');
end