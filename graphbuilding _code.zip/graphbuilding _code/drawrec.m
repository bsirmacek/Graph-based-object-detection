
function drawrec(g2, loc, mask)

f = size(g2(:,1));

for (j = 1 : f)
    if(loc(g2(j,3),2) < loc(g2(j,4),2))
        x1 = loc(g2(j,3),2);
        x2 = loc(g2(j,4),2);
    else
        x1 = loc(g2(j,4),2); %x1 is always smaller one
        x2 = loc(g2(j,3),2); 
    end
    if(loc(g2(j,3),1) < loc(g2(j,4),1))
        y1 = loc(g2(j,3),1);
        y2 = loc(g2(j,4),1);
    else
        y1 = loc(g2(j,4),1); % y1 is always smaller one
        y2 = loc(g2(j,3),1);
    end
    rectangle('position', [x1, y1, (x2-x1+1), (y2-y1+1)], 'facecolor', 'y');
end