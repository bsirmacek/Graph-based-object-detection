clear all
close all
clc
warning off;
iptsetpref('ImshowBorder','tight');
 
imgt=[];

%fixc=450; imnum=[1:7 9:11];
fixc=300; imnum=[12:19];
%fixc=300; imnum=[1:7 9:11];

rowline=255*ones(3,3*fixc+6,3);

for in=imnum
    
img1 =imread(['results2/adana' num2str(in) '.tif']);
img2 =imread(['results2/adana' num2str(in) '_residential.tif']);
img3 =imread(['results2/adana' num2str(in) '_buildings.tif']);

img1=imresize(img1,[nan fixc]);
img2=imresize(img2,[nan fixc]);
img3=imresize(img3,[nan fixc]);

[sx,sy,sz]=size(img1);

colline=255*ones(sx,3,sz);

if sum(imgt(:,:,:))
imgt=[imgt; rowline;img1 colline img2 colline img3];
else
imgt=[img1 colline img2 colline img3];
end;

end;%for imnum

imshow(imgt);
