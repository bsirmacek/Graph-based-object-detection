clear all
close all
clc
warning off;
iptsetpref('ImshowBorder','tight');
 
%for count=1:19 
%for count=1:5
for count=1:4 
    close all;pause(0.01);
    
%imname = ['adana' num2str(count)];
%imname = ['ankara' num2str(count)];
imname = ['istanbul' num2str(count)];

disp(imname)
pause(0.01);

img1 =imread(['images/' imname '.tif']);

if(size(img1,3)==3)
    img1 = rgb2gray(img1);
end


%% preprocess:
img = (double(img1)*255)/65535; clear img1,

im1 = imresize(img,6,'bilinear');
w     = 5;       % bilateral filter half-width
sigma = [3 0.1]; % bilateral filter standard deviations
img1 = double(im1)/max(im1(:));
bflt_img1 = bfilter2(img1,w,sigma);
img1 = 255*bflt_img1;

load temp1;load temp2
%%  sift:

[des1, loc1] = sift(img1);
[dest1, loct1] = sift(temp1);
[dest2, loct2] = sift(temp2);

%% multiple matching:

% match with 1st model image:
[locst1, locs1, match1, N1] = matchspecial5(dest1, des1, loct1, loc1);

% match with 2nd model image:
[locst2, locs2, match2, N2] = matchspecial5(dest2, des1, loct2, loc1);

% shift keys towards the buildings:
lc1 = shiftkeys(img1, locs1);
lc2 = shiftkeys(img1, locs2);

%% construct graph:
[dis1] = distance2(loc1', loc1');
[distt1] = distance2(loct1', loct1');
[distt2] = distance2(loct2', loct2');

%% find residential regions:

err = 4;
% find sub-graphs
g1 = makesub2(img1, distt1, dis1, loct1, loc1, match1, err);
g2 = makesub2(img1, distt2, dis1, loct2, loc1, match2, err);

region_mask1 = findregionmask3(img1, g1, loc1);
region_mask2 = findregionmask3(img1, g2, loc1);

[sx sy]=size(img);

mask = (region_mask1  | region_mask2);


mask=imresize(mask,[sx sy],'nearest');

[k,l]=find(edge(uint8(mask)));

for a=1:length(k)
    img(k(a),l(a))=253;
end;%for a

imwrite(mask,['results4\' imname '_res.tif'],'tiff');
%imwrite(img,['results\' imname '_mask.tif'],'tiff');

end;%for count

