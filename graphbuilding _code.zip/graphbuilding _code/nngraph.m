function g4 = nngraph(img1, dis1, lc1, int_err, dist_cut)

h=1; 
f1 = size(lc1,1);
% dist_cut = 30;
%figure, imshow(img1,[]); hold on,

for i = 1:f1 % take a key point in template
    
    %a2 = match1(i,2);
    int2 = img1(round(lc1(i,1)), round(lc1(i,2)));
    
    if (int2 > 80) %if it is not a background feature
        %plot(round(lc1(i,2)), round(lc1(i,1)),'.b'); hold on,
        [y, ind] = sort(dis1(i,:));
    
        % en yak�n 10 kom�uluk: 
        a2 = i;
        a3 = ind(2);
        a4 = ind(3);
        a5 = ind(4);
        a6 = ind(5);
        a7 = ind(6);
        a8 = ind(7);
        a9 = ind(8);
        a10 = ind(9);
        a11 = ind(10);
    
    
        int3 = img1(round(lc1(a3,1)), round(lc1(a3,2)));
        int4 = img1(round(lc1(a4,1)), round(lc1(a4,2)));
        int5 = img1(round(lc1(a5,1)), round(lc1(a5,2)));
        int6 = img1(round(lc1(a6,1)), round(lc1(a6,2)));
        int7 = img1(round(lc1(a7,1)), round(lc1(a7,2)));
        int8 = img1(round(lc1(a8,1)), round(lc1(a8,2)));
        int9 = img1(round(lc1(a9,1)), round(lc1(a9,2)));
        int10 = img1(round(lc1(a10,1)), round(lc1(a10,2)));
        int11 = img1(round(lc1(a11,1)), round(lc1(a11,2)));
    
        if(abs(int2-int3) < int_err)
            if(dis1(a2,a3)<dist_cut)
                g4(h,:) = [i,a3]; h = h+1;
            end
        end
    
        if(abs(int2-int4) < int_err)
            if(dis1(a2,a4)<dist_cut)
                g4(h,:) = [i a4]; h = h+1;
            end
        end
    
        if(abs(int2-int5) < int_err)
            if(dis1(a2,a5)<dist_cut)
                g4(h,:) = [i a5]; h = h+1;
            end
        end

        if(abs(int2-int6) < int_err)
            if(dis1(a2,a6)<dist_cut)
                g4(h,:) = [i a6]; h = h+1;
            end
        end
        
        if(abs(int2-int7) < int_err)
            if(dis1(a2,a7)<dist_cut)
                g4(h,:) = [i a7]; h = h+1;
            end
        end
        
        if(abs(int2-int8) < int_err)
            if(dis1(a2,a8)<dist_cut)
                g4(h,:) = [i a8]; h = h+1;
            end
        end
        
        if(abs(int2-int9) < int_err)
            if(dis1(a2,a9)<dist_cut)
                g4(h,:) = [i a9]; h = h+1;
            end
        end
        
        if(abs(int2-int10) < int_err)
            if(dis1(a2,a10)<dist_cut)
                g4(h,:) = [i a10]; h = h+ 1;
            end
        end    
        
        if(abs(int2-int11) < int_err)
            if(dis1(a2,a11)<dist_cut)
                g4(h,:) = [i a11]; h = h+ 1;
            end
        end 
        
                
    end
end


%% draw subgraphs

%Show a figure with lines joining the accepted matches
% a = 255*ones(size(img1));
% a(1:5,:)=0;
% a(end-5:end,:)=0;
% a(:,1:5)=0;
% a(:,end-5:end)=0;
%figure, imshow(255*ones(size(img1)), []); hold on,
figure, imshow(img1,[]); hold on

if (h>1)
    f = size(g4,1);
        
    for j = 1 : f
        line([lc1(g4(j,1),2) lc1(g4(j,2),2)], ...
        [lc1(g4(j,1),1) lc1(g4(j,2),1)], 'Color', 'r', 'LineWidth', 1);        
        plot(lc1(g4(j,1),2), lc1(g4(j,1),1), '.b', 'Markersize', 10);
        plot(lc1(g4(j,2),2),lc1(g4(j,2),1), '.b', 'Markersize', 10);
     end
else
    g4 = 0;
    disp('no match');
end
hold off;

% %% delete repeated locs:
% 
% del = 0;
% 
% k = 1;
% for(i = 1:size(g4,1))
%     
%     ff = isempty(find(del == i));
%     if( ff == 1)
%         x = lc1(g4(i,1),2); y = lc1(g4(i,1),1); 
%         a = find(lc1(g4(:,1),2) == x); b = find(lc1(g4(:,1),1) == y);
%         
%         if(a>1)
%             del = [del;a];
%             g5(k,:) = g4(i,:); k = k+1;
%         end
%     end
% end



                    


