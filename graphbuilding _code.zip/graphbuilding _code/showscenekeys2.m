

function showscenekeys2(im, loc)


figure, imshow(255*ones(size(im))),hold on;

f = size(loc(:,1));

for(i = 1:f)
    plot(loc(i,2),loc(i,1),'.b','MarkerSize',20);
end

hold off;