


function [dis] = distance2(a,b)

if (nargin ~= 2)
   error('Not enough input arguments');
end

if (size(a,1) ~= size(b,1))
   error('A and B should be of same dimensionality');
end

aa=sum(a.*a,1); bb=sum(b.*b,1); ab=a'*b; 
d = sqrt(abs(repmat(aa',[1 size(bb,2)]) + repmat(bb,[size(aa,2) 1]) - 2*ab));

[k,l] = find(d==0);
dis=d;
for(i = 1:size(k))
    if(k(i)~=l(i))
        dis(k(i),l(i))=100000;
    end
end


        