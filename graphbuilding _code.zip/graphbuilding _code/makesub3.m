

function [g2] = makesub3(im, dis1, dis2, lc1, lc2, matchs, err)

h=1; 
f1 = size(matchs(:,1));

for(i = 1:f1) % take a key point in template
    a1 = matchs(i,1);
    a2 = matchs(i,2);
    for (j = 1:f1) % take another key point in template        
        if (i~=j) %if it is not the same key point
            b1 = matchs(j,1);
            b2 = matchs(j,2);
            r1 = dis1(a1,b1); %key point distances in template
            r2 = dis2(a2,b2);
            if(abs(r1-r2)<err)
                g2(h,:) = [a1 b1 a2 b2]; h = h + 1;
            end
        end
    end
end


%% draw subgraphs

%Show a figure with lines joining the accepted matches
figure, imshow(im, []);
if (h>1)
    f = size(g2(:,1));

    hold on;
        
    lc2=lc2/6;
    
    for j = 1 : f       
       line([lc2(g2(j,3),2) lc2(g2(j,4),2)], ...
         [lc2(g2(j,3),1) lc2(g2(j,4),1)], 'Color', 'r', 'LineWidth', .5);
         hold on;
%        plot(lc2(g2(j,3),2), lc2(g2(j,3),1), '.b', 'Markersize', 10);
%        plot(lc2(g2(j,4),2),lc2(g2(j,4),1), '.b', 'Markersize', 10);
%adana 8 demo icin
        plot(lc2(g2(j,3),2), lc2(g2(j,3),1), '.b', 'Markersize', 5);
        plot(lc2(g2(j,4),2),lc2(g2(j,4),1), '.b', 'Markersize', 5);

    end
else
    g2 = 0;
end
hold off;





                    


